<?php
/*
 * Ladybug: Simple and Extensible PHP Dumper
 * 
 * Invalid format exception
 *
 * (c) Raúl Fraile Beneyto <raulfraile@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Ladybug\Exception;

class InvalidFormatException extends \Exception
{
    
}