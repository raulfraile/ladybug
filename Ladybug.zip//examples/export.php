<?php
require_once __DIR__.'/../lib/Ladybug/Autoloader.php';
Ladybug\Ladybug_Autoloader::register();

$var1 = NULL;
$var2 = 15;
$var3 = 15.5;
$var4 = 'hello world!';
$var5 = false;
$var6 = new \DateTime();
$var7 = array(1, 2, 3, new \DateTime());
$file = fopen(__DIR__ . '/../LICENSE', 'r');

echo ladybug_dump_return('json', $file);
